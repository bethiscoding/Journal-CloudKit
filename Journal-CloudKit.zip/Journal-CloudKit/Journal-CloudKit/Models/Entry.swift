//
//  Entry.swift
//  Journal-CloudKit
//
//  Created by Bethany Morris on 5/11/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import Foundation
import CloudKit

struct EntryStrings {
    static let recordTypeKey = "Entry"
    static let titleKey = "title"
    static let timestampKey = "timestamp"
    static let bodyKey = "body"
}

// MARK: - Entry class

class Entry {
    
    var title: String
    var timestamp: Date
    var body: String
    
    init(title: String, timestamp: Date = Date(), body: String) {
        self.title = title
        self.timestamp = timestamp
        self.body = body
    }
}

extension Entry {
    
    convenience init?(ckRecord: CKRecord) {
        guard let title = ckRecord[EntryStrings.titleKey] as? String,
              let timestamp = ckRecord[EntryStrings.timestampKey] as? Date,
              let body = ckRecord[EntryStrings.bodyKey] as? String
              else { return nil }
        
        self.init(title: title, timestamp: timestamp, body: body)
    }
}

// MARK: - CKRecord Convenience init

extension CKRecord {
    
    convenience init(entry: Entry) {
        self.init(recordType: EntryStrings.recordTypeKey)
        
        self.setValuesForKeys([
            EntryStrings.titleKey : entry.title,
            EntryStrings.timestampKey : entry.timestamp,
            EntryStrings.bodyKey : entry.body
        ])
    }
}
