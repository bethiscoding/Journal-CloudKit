//
//  EntryDetailViewController.swift
//  Journal-CloudKit
//
//  Created by Bethany Morris on 5/11/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit

class EntryDetailViewController: UIViewController {

    // MARK: - Outlets & Properties
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var bodyTextView: UITextView!
    
    var entry: Entry?
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
        titleTextField.delegate = self
    }
    
    // MARK: - Actions & Methods
    
    @IBAction func mainViewTapped(_ sender: UITapGestureRecognizer) {
        titleTextField.resignFirstResponder()
        bodyTextView.resignFirstResponder()
    }
    
    @IBAction func clearButtonTapped(_ sender: UIButton) {
        titleTextField.text = ""
        bodyTextView.text = "Write your entry here..."
    }
    
    @IBAction func saveButtonTapped(_ sender: UIBarButtonItem) {
        guard let title = titleTextField.text, !title.isEmpty, let body = bodyTextView.text, !body.isEmpty else { return }
        
        if let entry = entry {
            EntryController.sharedInstance.saveEntry(entry: entry) { (_) in
                DispatchQueue.main.async {
                    self.navigationController?.popViewController(animated: true)
                }
            }
        } else {
            EntryController.sharedInstance.createEntry(title: title, body: body) { (_) in
                DispatchQueue.main.async {
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
    
    func updateViews() {
        guard let entry = entry else { return }
        titleTextField.text = entry.title
        dateLabel.text = entry.timestamp.formatDate()
        bodyTextView.text = entry.body
        title = entry.title
    }

} //End

extension EntryDetailViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}
