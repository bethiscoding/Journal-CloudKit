//
//  EntryController.swift
//  Journal-CloudKit
//
//  Created by Bethany Morris on 5/11/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import Foundation
import CloudKit

class EntryController {
    
    // MARK: - Singleton
    
    static let sharedInstance = EntryController()
    
    // MARK: - Source of Truth
    
    var entries: [Entry] = []
    
    // MARK: - Properties
    
    let privateDB = CKContainer.default().privateCloudDatabase
    
    // MARK: - CRUD Methods
    
    func createEntry(title: String, body: String, completion: @escaping (Result<Entry?, EntryError>) -> Void ) {
        
        let newEntry = Entry(title: title, body: body)
        self.saveEntry(entry: newEntry) { (result) in
            switch result {
            case .success(let entry):
                guard let entry = entry else { return }
                self.entries.insert(entry, at: 0)
                return completion(.success(entry))
            case .failure(let error):
                print(error.errorDescription)
                return completion(.failure(error))
            }
        }
    }
    
    func saveEntry(entry: Entry, completion: @escaping (Result<Entry?, EntryError>) -> Void ) {
        
        let entryRecord = CKRecord(entry: entry)
        
        privateDB.save(entryRecord) { (record, error) in
            
            if let error = error {
                return completion(.failure(.ckError(error)))
            }
            
            guard let record = record,
                  let savedEntry = Entry(ckRecord: record)
                  else { return completion(.failure(.couldNotUnwrap))}
            print("Saved entry successfully")
            completion(.success(savedEntry))
        }
    }
    
    func fetchEntries(completion: @escaping (Result<[Entry]?, EntryError>) -> Void ) {
        
        let fetchEntriesPredicate = NSPredicate(value: true)
        let query = CKQuery(recordType: EntryStrings.recordTypeKey, predicate: fetchEntriesPredicate)
        
        privateDB.perform(query, inZoneWith: nil) { (records, error) in
            
            if let error = error {
                return completion(.failure(.ckError(error)))
            }
            
            guard let records = records else { return completion(.failure(.couldNotUnwrap))}
            print("Fetched all entries successfully.")
            let entries = records.compactMap( { Entry(ckRecord: $0)} )
            completion(.success(entries))
        }
    }
    
} //End
